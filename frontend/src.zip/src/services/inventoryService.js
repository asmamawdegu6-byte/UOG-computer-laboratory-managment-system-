export const inventoryService = {};  
