import React from 'react';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <p>&copy; {currentYear} Computer Lab Management System</p>
        </div>
        <div className="footer-section">
          <p>University of Gondar</p>
        </div>
        <div className="footer-links">
          <a href="/privacy">Privacy Policy</a>
          <a href="/terms">Terms of Use</a>
          <a href="/support">Support</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;