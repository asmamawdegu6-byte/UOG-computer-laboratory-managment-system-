import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

// Layouts
import AuthLayout from '../components/layout/AuthLayout';

// Auth Pages
import Login from '../pages/auth/Login';
import Register from '../pages/auth/Register';
import ForgotPassword from '../pages/auth/ForgotPassword';

// Student Pages
import StudentDashboard from '../pages/student/StudentDashboard';
import ViewAvailability from '../pages/student/ViewAvailability';
import BookWorkstation from '../pages/student/BookWorkstation';
import MyBookings from '../pages/student/MyBookings';
import ReportFault from '../pages/student/ReportFault';
import DownloadMaterial from '../pages/student/DownloadMaterial';
import BookingHistory from '../pages/student/BookingHistory';

// Teacher Pages
import TeacherDashboard from '../pages/teacher/TeacherDashboard';
import LabReservation from '../pages/teacher/LabReservation';

// Route Guards
import PrivateRoute from './PrivateRoute';
import RoleBasedRoute from './RoleBasedRoute';

const AppRoutes = () => {
  const { isAuthenticated, user } = useAuth();

  return (
    <Routes>
      {/* Public Routes */}
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
      </Route>

      {/* Student Routes */}
      <Route element={<RoleBasedRoute allowedRoles={['student']} />}>
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        <Route path="/student/availability" element={<ViewAvailability />} />
        <Route path="/student/book" element={<BookWorkstation />} />
        <Route path="/student/bookings" element={<MyBookings />} />
        <Route path="/student/report-fault" element={<ReportFault />} />
        <Route path="/student/materials" element={<DownloadMaterial />} />
        <Route path="/student/history" element={<BookingHistory />} />
      </Route>

      {/* Teacher Routes */}
      <Route element={<RoleBasedRoute allowedRoles={['teacher']} />}>
        <Route path="/teacher/dashboard" element={<TeacherDashboard />} />
        <Route path="/teacher/reservation" element={<LabReservation />} />
        {/* Add other teacher routes */}
      </Route>

      {/* Default Redirect */}
      <Route 
        path="/" 
        element={
          isAuthenticated ? 
            <Navigate to={`/${user?.role}/dashboard`} replace /> : 
            <Navigate to="/login" replace />
        } 
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default AppRoutes;