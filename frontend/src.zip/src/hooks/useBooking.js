export const useBooking = () = 
