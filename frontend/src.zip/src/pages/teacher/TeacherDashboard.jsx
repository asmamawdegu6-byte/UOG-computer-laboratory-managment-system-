import React from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/ui/Card';
import './TeacherDashboard.css';

const TeacherDashboard = () => {
  const stats = [
    { label: 'Active Reservations', value: 3, icon: '📅' },
    { label: 'Total Students', value: 120, icon: '👨‍🎓' },
    { label: 'Materials Uploaded', value: 25, icon: '📤' },
    { label: 'Fault Reports', value: 2, icon: '🔧' }
  ];

  const upcomingClasses = [
    { id: 1, subject: 'Introduction to Programming', lab: 'Lab A', date: '2026-03-26', time: '09:00 - 11:00', students: 30 },
    { id: 2, subject: 'Database Systems', lab: 'Lab B', date: '2026-03-27', time: '14:00 - 16:00', students: 25 }
  ];

  return (
    <DashboardLayout>
      <div className="teacher-dashboard">
        <h1>Teacher Dashboard</h1>
        <p className="welcome-text">Manage your lab sessions and monitor student activity.</p>

        <div className="stats-grid">
          {stats.map((stat, index) => (
            <Card key={index} className="stat-card">
              <div className="stat-icon">{stat.icon}</div>
              <div className="stat-value">{stat.value}</div>
              <div className="stat-label">{stat.label}</div>
            </Card>
          ))}
        </div>

        <Card title="Upcoming Lab Sessions" className="sessions-card">
          <table className="sessions-table">
            <thead>
              <tr>
                <th>Subject</th>
                <th>Lab</th>
                <th>Date</th>
                <th>Time</th>
                <th>Students</th>
              </tr>
            </thead>
            <tbody>
              {upcomingClasses.map((session) => (
                <tr key={session.id}>
                  <td>{session.subject}</td>
                  <td>{session.lab}</td>
                  <td>{session.date}</td>
                  <td>{session.time}</td>
                  <td>{session.students}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default TeacherDashboard;