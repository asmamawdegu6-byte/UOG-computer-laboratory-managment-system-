import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { bookingService } from '../../services/bookingService';
import './LabReservation.css';

const LabReservation = () => {
  const [labs, setLabs] = useState([]);
  const [formData, setFormData] = useState({
    labId: '',
    date: '',
    startTime: '',
    endTime: '',
    subject: '',
    studentCount: '',
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchLabs();
  }, []);

  const fetchLabs = async () => {
    try {
      const response = await bookingService.getLabs();
      setLabs(response.data);
    } catch (error) {
      console.error('Error fetching labs:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const result = await bookingService.createReservation(formData);
      setMessage(result.success ? 'Reservation successful!' : result.message);
      if (result.success) {
        setFormData({ labId: '', date: '', startTime: '', endTime: '', subject: '', studentCount: '', notes: '' });
      }
    } catch (error) {
      setMessage('An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="lab-reservation">
        <h1>Lab Reservation</h1>
        <Card>
          {message && <div className="message">{message}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Select Lab</label>
              <select name="labId" value={formData.labId} onChange={handleChange} required>
                <option value="">Choose a lab...</option>
                {labs.map(lab => <option key={lab.id} value={lab.id}>{lab.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Subject</label>
              <input type="text" name="subject" value={formData.subject} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Date</label>
              <input type="date" name="date" value={formData.date} onChange={handleChange} required />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Start Time</label>
                <input type="time" name="startTime" value={formData.startTime} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>End Time</label>
                <input type="time" name="endTime" value={formData.endTime} onChange={handleChange} required />
              </div>
            </div>
            <div className="form-group">
              <label>Student Count</label>
              <input type="number" name="studentCount" value={formData.studentCount} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Notes</label>
              <textarea name="notes" value={formData.notes} onChange={handleChange} rows="3" />
            </div>
            <Button type="submit" variant="primary" loading={loading}>Reserve Lab</Button>
          </form>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default LabReservation;