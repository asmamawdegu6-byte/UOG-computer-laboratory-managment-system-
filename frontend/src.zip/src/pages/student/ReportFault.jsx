import React, { useState } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import './ReportFault.css';

const ReportFault = () => {
  const [formData, setFormData] = useState({
    labId: '',
    workstationId: '',
    faultType: '',
    severity: 'medium',
    description: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const labs = [
    { id: 'lab-a', name: 'Computer Lab A' },
    { id: 'lab-b', name: 'Computer Lab B' },
    { id: 'lab-c', name: 'Computer Lab C' },
    { id: 'lab-d', name: 'Multimedia Lab' },
    { id: 'lab-e', name: 'Programming Lab' },
  ];

  const faultTypes = [
    { id: 'hardware', name: 'Hardware Issue', icon: '🔧' },
    { id: 'software', name: 'Software Problem', icon: '💻' },
    { id: 'network', name: 'Network Issue', icon: '🌐' },
    { id: 'peripheral', name: 'Peripheral Problem', icon: '🖱️' },
    { id: 'other', name: 'Other', icon: '⚠️' },
  ];

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  if (submitted) {
    return (
      <DashboardLayout>
        <div className="report-fault">
          <div className="success-container">
            <div className="success-icon">✓</div>
            <h1>Fault Reported Successfully!</h1>
            <p>Thank you for reporting. Our technicians will look into this issue.</p>
            <div className="ticket-info">
              <div className="ticket-number">
                <span>Ticket Number</span>
                <strong>TKT-{Math.random().toString(36).substr(2, 6).toUpperCase()}</strong>
              </div>
            </div>
            <div className="success-actions">
              <button onClick={() => window.location.reload()} className="btn-primary">
                Report Another Fault
              </button>
              <a href="/student/dashboard" className="btn-secondary">Back to Dashboard</a>
            </div>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="report-fault">
        <div className="page-header">
          <h1>Report a Fault</h1>
          <p>Report hardware or software issues in the computer labs</p>
        </div>

        <div className="fault-form-container">
          {/* Severity Level Info */}
          <div className="severity-info">
            <h3>Severity Levels</h3>
            <div className="severity-levels">
              <div className="severity-item low">
                <span className="dot"></span>
                <div>
                  <strong>Low</strong>
                  <p>Minor issues that don't affect work</p>
                </div>
              </div>
              <div className="severity-item medium">
                <span className="dot"></span>
                <div>
                  <strong>Medium</strong>
                  <p>Issues affecting some functionality</p>
                </div>
              </div>
              <div className="severity-item high">
                <span className="dot"></span>
                <div>
                  <strong>High</strong>
                  <p>Critical issues preventing work</p>
                </div>
              </div>
            </div>
          </div>

          {/* Report Form */}
          <form onSubmit={handleSubmit} className="fault-form">
            <div className="form-section">
              <h3>Location Details</h3>
              <div className="form-row">
                <div className="form-group">
                  <label>Select Lab *</label>
                  <select 
                    name="labId" 
                    required
                    value={formData.labId}
                    onChange={handleChange}
                  >
                    <option value="">Choose a lab...</option>
                    {labs.map(lab => (
                      <option key={lab.id} value={lab.id}>{lab.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>Workstation ID *</label>
                  <input 
                    type="text" 
                    name="workstationId"
                    placeholder="e.g., PC-12"
                    required
                    value={formData.workstationId}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="form-section">
              <h3>Fault Details</h3>
              <div className="form-group">
                <label>Fault Type *</label>
                <div className="fault-type-grid">
                  {faultTypes.map(type => (
                    <div 
                      key={type.id}
                      className={`fault-type-card ${formData.faultType === type.id ? 'selected' : ''}`}
                      onClick={() => setFormData({ ...formData, faultType: type.id })}
                    >
                      <span className="fault-icon">{type.icon}</span>
                      <span>{type.name}</span>
                    </div>
                  ))}
                </div>
                <input type="hidden" name="faultType" value={formData.faultType} required />
              </div>

              <div className="form-group">
                <label>Severity Level *</label>
                <div className="severity-selector">
                  <label className={`severity-option ${formData.severity === 'low' ? 'selected' : ''}`}>
                    <input 
                      type="radio" 
                      name="severity" 
                      value="low"
                      checked={formData.severity === 'low'}
                      onChange={handleChange}
                    />
                    <span className="severity-label low">Low</span>
                  </label>
                  <label className={`severity-option ${formData.severity === 'medium' ? 'selected' : ''}`}>
                    <input 
                      type="radio" 
                      name="severity" 
                      value="medium"
                      checked={formData.severity === 'medium'}
                      onChange={handleChange}
                    />
                    <span className="severity-label medium">Medium</span>
                  </label>
                  <label className={`severity-option ${formData.severity === 'high' ? 'selected' : ''}`}>
                    <input 
                      type="radio" 
                      name="severity" 
                      value="high"
                      checked={formData.severity === 'high'}
                      onChange={handleChange}
                    />
                    <span className="severity-label high">High</span>
                  </label>
                </div>
              </div>

              <div className="form-group">
                <label>Description *</label>
                <textarea 
                  name="description"
                  rows="4"
                  placeholder="Please describe the issue in detail..."
                  required
                  value={formData.description}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="form-actions">
              <button type="submit" className="btn-submit" disabled={loading}>
                {loading ? (
                  <>
                    <span className="spinner"></span>
                    Submitting...
                  </>
                ) : (
                  'Submit Report'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default ReportFault;
