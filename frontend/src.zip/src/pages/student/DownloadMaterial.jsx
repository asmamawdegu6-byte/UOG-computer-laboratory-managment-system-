import React, { useState } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import './DownloadMaterial.css';

const DownloadMaterial = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [downloading, setDownloading] = useState(null);

  const categories = [
    { id: 'all', name: 'All Materials', icon: '📁' },
    { id: 'programming', name: 'Programming', icon: '💻' },
    { id: 'database', name: 'Database', icon: '🗄️' },
    { id: 'networking', name: 'Networking', icon: '🌐' },
    { id: 'multimedia', name: 'Multimedia', icon: '🎨' },
    { id: 'documentation', name: 'Documentation', icon: '📄' },
  ];

  const materials = [
    {
      id: 1,
      title: 'Introduction to Python Programming',
      category: 'programming',
      fileType: 'PDF',
      fileSize: '2.5 MB',
      uploadedBy: 'Dr. Smith',
      uploadDate: '2026-03-20',
      downloads: 156,
      description: 'Comprehensive guide to Python basics including variables, loops, and functions.'
    },
    {
      id: 2,
      title: 'Database Design Fundamentals',
      category: 'database',
      fileType: 'PDF',
      fileSize: '4.1 MB',
      uploadedBy: 'Prof. Johnson',
      uploadDate: '2026-03-18',
      downloads: 89,
      description: 'Learn about ER diagrams, normalization, and SQL queries.'
    },
    {
      id: 3,
      title: 'Network Configuration Lab Manual',
      category: 'networking',
      fileType: 'DOCX',
      fileSize: '1.8 MB',
      uploadedBy: 'Mr. Williams',
      uploadDate: '2026-03-15',
      downloads: 124,
      description: 'Step-by-step guide for network setup and configuration.'
    },
    {
      id: 4,
      title: 'Adobe Photoshop Tutorial',
      category: 'multimedia',
      fileType: 'ZIP',
      fileSize: '15.2 MB',
      uploadedBy: 'Ms. Davis',
      uploadDate: '2026-03-12',
      downloads: 203,
      description: 'Complete tutorial with sample files for photo editing.'
    },
    {
      id: 5,
      title: 'Java Programming Exercises',
      category: 'programming',
      fileType: 'ZIP',
      fileSize: '3.2 MB',
      uploadedBy: 'Dr. Smith',
      uploadDate: '2026-03-10',
      downloads: 178,
      description: 'Practice exercises with solutions for Java OOP concepts.'
    },
    {
      id: 6,
      title: 'Lab Safety Guidelines',
      category: 'documentation',
      fileType: 'PDF',
      fileSize: '512 KB',
      uploadedBy: 'Admin',
      uploadDate: '2026-03-01',
      downloads: 342,
      description: 'Important safety rules and regulations for all lab users.'
    },
  ];

  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || material.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleDownload = (materialId) => {
    setDownloading(materialId);
    setTimeout(() => {
      setDownloading(null);
      alert('Download started!');
    }, 1500);
  };

  const getFileIcon = (fileType) => {
    const icons = {
      'PDF': '📕',
      'DOCX': '📘',
      'ZIP': '📦',
      'PPTX': '📙',
      'XLSX': '📗',
    };
    return icons[fileType] || '📄';
  };

  return (
    <DashboardLayout>
      <div className="download-material">
        <div className="page-header">
          <h1>Download Materials</h1>
          <p>Access course materials, tutorials, and lab resources</p>
        </div>

        {/* Search and Filter */}
        <div className="search-filter-section">
          <div className="search-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/>
              <line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input 
              type="text" 
              placeholder="Search materials..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="category-filter">
          {categories.map(cat => (
            <button
              key={cat.id}
              className={`category-btn ${selectedCategory === cat.id ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat.id)}
            >
              <span className="cat-icon">{cat.icon}</span>
              <span>{cat.name}</span>
            </button>
          ))}
        </div>

        {/* Results Count */}
        <div className="results-count">
          Showing {filteredMaterials.length} material{filteredMaterials.length !== 1 ? 's' : ''}
        </div>

        {/* Materials Grid */}
        <div className="materials-grid">
          {filteredMaterials.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📭</div>
              <h3>No materials found</h3>
              <p>Try adjusting your search or category filter</p>
            </div>
          ) : (
            filteredMaterials.map(material => (
              <div key={material.id} className="material-card">
                <div className="material-header">
                  <div className="file-icon">{getFileIcon(material.fileType)}</div>
                  <div className="file-meta">
                    <span className="file-type">{material.fileType}</span>
                    <span className="file-size">{material.fileSize}</span>
                  </div>
                </div>

                <h3 className="material-title">{material.title}</h3>
                <p className="material-description">{material.description}</p>

                <div className="material-info">
                  <div className="info-item">
                    <span className="label">Uploaded by:</span>
                    <span>{material.uploadedBy}</span>
                  </div>
                  <div className="info-item">
                    <span className="label">Date:</span>
                    <span>{material.uploadDate}</span>
                  </div>
                  <div className="info-item">
                    <span className="label">Downloads:</span>
                    <span>{material.downloads}</span>
                  </div>
                </div>

                <button 
                  className="download-btn"
                  onClick={() => handleDownload(material.id)}
                  disabled={downloading === material.id}
                >
                  {downloading === material.id ? (
                    <>
                      <span className="spinner"></span>
                      Downloading...
                    </>
                  ) : (
                    <>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                      </svg>
                      Download
                    </>
                  )}
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default DownloadMaterial;
