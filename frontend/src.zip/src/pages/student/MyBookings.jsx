import React, { useState } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import './MyBookings.css';

const MyBookings = () => {
  const [activeTab, setActiveTab] = useState('active');

  // Mock bookings data
  const bookings = {
    active: [
      {
        id: 'BK001',
        lab: 'Computer Lab A',
        workstation: 'PC 12',
        date: '2026-03-26',
        startTime: '09:00',
        endTime: '11:00',
        status: 'confirmed',
        bookingDate: '2026-03-24'
      },
      {
        id: 'BK002',
        lab: 'Computer Lab C',
        workstation: 'PC 05',
        date: '2026-03-27',
        startTime: '14:00',
        endTime: '16:00',
        status: 'pending',
        bookingDate: '2026-03-25'
      }
    ],
    upcoming: [
      {
        id: 'BK003',
        lab: 'Computer Lab B',
        workstation: 'PC 20',
        date: '2026-03-30',
        startTime: '10:00',
        endTime: '12:00',
        status: 'confirmed',
        bookingDate: '2026-03-25'
      }
    ],
    past: [
      {
        id: 'BK000',
        lab: 'Computer Lab A',
        workstation: 'PC 08',
        date: '2026-03-20',
        startTime: '13:00',
        endTime: '15:00',
        status: 'completed',
        bookingDate: '2026-03-18'
      }
    ]
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      confirmed: { class: 'status-confirmed', label: 'Confirmed' },
      pending: { class: 'status-pending', label: 'Pending' },
      completed: { class: 'status-completed', label: 'Completed' },
      cancelled: { class: 'status-cancelled', label: 'Cancelled' }
    };
    const config = statusConfig[status] || statusConfig.pending;
    return <span className={`status-badge ${config.class}`}>{config.label}</span>;
  };

  const handleCancel = (bookingId) => {
    if (window.confirm('Are you sure you want to cancel this booking?')) {
      alert(`Booking ${bookingId} cancelled successfully!`);
    }
  };

  return (
    <DashboardLayout>
      <div className="my-bookings">
        <div className="page-header">
          <h1>My Bookings</h1>
          <p>Manage your lab workstation bookings</p>
        </div>

        {/* Stats Cards */}
        <div className="booking-stats">
          <div className="stat-card blue">
            <div className="stat-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                <line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
            </div>
            <div className="stat-info">
              <h3>{bookings.active.length}</h3>
              <p>Active Bookings</p>
            </div>
          </div>
          <div className="stat-card green">
            <div className="stat-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                <polyline points="22 4 12 14.01 9 11.01"/>
              </svg>
            </div>
            <div className="stat-info">
              <h3>{bookings.upcoming.length}</h3>
              <p>Upcoming</p>
            </div>
          </div>
          <div className="stat-card purple">
            <div className="stat-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
              </svg>
            </div>
            <div className="stat-info">
              <h3>{bookings.past.length}</h3>
              <p>Past Bookings</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="tabs-container">
          <div className="tabs">
            <button 
              className={activeTab === 'active' ? 'active' : ''}
              onClick={() => setActiveTab('active')}
            >
              Active ({bookings.active.length})
            </button>
            <button 
              className={activeTab === 'upcoming' ? 'active' : ''}
              onClick={() => setActiveTab('upcoming')}
            >
              Upcoming ({bookings.upcoming.length})
            </button>
            <button 
              className={activeTab === 'past' ? 'active' : ''}
              onClick={() => setActiveTab('past')}
            >
              History ({bookings.past.length})
            </button>
          </div>

          {/* Bookings List */}
          <div className="bookings-list">
            {bookings[activeTab].length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                    <line x1="16" y1="2" x2="16" y2="6"/>
                    <line x1="8" y1="2" x2="8" y2="6"/>
                    <line x1="3" y1="10" x2="21" y2="10"/>
                  </svg>
                </div>
                <h3>No bookings found</h3>
                <p>You don't have any {activeTab} bookings.</p>
                <a href="/student/book" className="btn-book">Book a Workstation</a>
              </div>
            ) : (
              bookings[activeTab].map((booking) => (
                <div key={booking.id} className="booking-card">
                  <div className="booking-header">
                    <div className="booking-id">
                      <span>Booking ID</span>
                      <strong>{booking.id}</strong>
                    </div>
                    {getStatusBadge(booking.status)}
                  </div>

                  <div className="booking-details">
                    <div className="detail-row">
                      <div className="detail-item">
                        <span className="label">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                            <polyline points="9 22 9 12 15 12 15 22"/>
                          </svg>
                          Lab
                        </span>
                        <strong>{booking.lab}</strong>
                      </div>
                      <div className="detail-item">
                        <span className="label">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                            <line x1="8" y1="21" x2="16" y2="21"/>
                            <line x1="12" y1="17" x2="12" y2="21"/>
                          </svg>
                          Workstation
                        </span>
                        <strong>{booking.workstation}</strong>
                      </div>
                    </div>

                    <div className="detail-row">
                      <div className="detail-item">
                        <span className="label">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                            <line x1="16" y1="2" x2="16" y2="6"/>
                            <line x1="8" y1="2" x2="8" y2="6"/>
                            <line x1="3" y1="10" x2="21" y2="10"/>
                          </svg>
                          Date
                        </span>
                        <strong>{booking.date}</strong>
                      </div>
                      <div className="detail-item">
                        <span className="label">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <circle cx="12" cy="12" r="10"/>
                            <polyline points="12 6 12 12 16 14"/>
                          </svg>
                          Time
                        </span>
                        <strong>{booking.startTime} - {booking.endTime}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="booking-footer">
                    <span className="booking-date">Booked on {booking.bookingDate}</span>
                    {(activeTab === 'active' || activeTab === 'upcoming') && (
                      <button 
                        className="btn-cancel"
                        onClick={() => handleCancel(booking.id)}
                      >
                        Cancel Booking
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default MyBookings;
