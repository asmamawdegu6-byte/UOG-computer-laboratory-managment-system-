import React, { useState } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import './BookWorkstation.css';

const BookWorkstation = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    labId: '',
    date: '',
    startTime: '',
    endTime: '',
    workstationId: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  // Mock data
  const labs = [
    { id: 'lab-a', name: 'Computer Lab A', capacity: 40 },
    { id: 'lab-b', name: 'Computer Lab B', capacity: 35 },
    { id: 'lab-c', name: 'Computer Lab C', capacity: 30 },
  ];

  const timeSlots = [
    '08:00', '09:00', '10:00', '11:00', '12:00',
    '13:00', '14:00', '15:00', '16:00', '17:00'
  ];

  const workstations = Array.from({ length: 20 }, (_, i) => ({
    id: `pc-${i + 1}`,
    name: `PC ${i + 1}`,
    status: Math.random() > 0.3 ? 'available' : 'occupied'
  }));

  const handleLabSelect = (labId) => {
    setFormData({ ...formData, labId });
    setStep(2);
  };

  const handleDateTimeSubmit = (e) => {
    e.preventDefault();
    setStep(3);
  };

  const handleWorkstationSelect = (workstationId) => {
    setFormData({ ...formData, workstationId });
  };

  const handleBooking = async () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
    }, 1500);
  };

  const selectedLab = labs.find(l => l.id === formData.labId);

  if (success) {
    return (
      <DashboardLayout>
        <div className="book-workstation">
          <div className="success-container">
            <div className="success-icon">✓</div>
            <h1>Booking Confirmed!</h1>
            <p>Your workstation has been successfully booked.</p>
            <div className="booking-details">
              <div className="detail-item">
                <span>Lab:</span>
                <strong>{selectedLab?.name}</strong>
              </div>
              <div className="detail-item">
                <span>Date:</span>
                <strong>{formData.date}</strong>
              </div>
              <div className="detail-item">
                <span>Time:</span>
                <strong>{formData.startTime} - {formData.endTime}</strong>
              </div>
              <div className="detail-item">
                <span>Workstation:</span>
                <strong>{formData.workstationId}</strong>
              </div>
            </div>
            <div className="success-actions">
              <a href="/student/my-bookings" className="btn-primary">View My Bookings</a>
              <button onClick={() => window.location.reload()} className="btn-secondary">Book Another</button>
            </div>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="book-workstation">
        <div className="page-header">
          <h1>Book a Workstation</h1>
          <p>Select your preferred lab, date, and workstation</p>
        </div>

        {/* Progress Steps */}
        <div className="progress-steps">
          <div className={`step ${step >= 1 ? 'active' : ''} ${step > 1 ? 'completed' : ''}`}>
            <div className="step-number">1</div>
            <span>Select Lab</span>
          </div>
          <div className="step-line"></div>
          <div className={`step ${step >= 2 ? 'active' : ''} ${step > 2 ? 'completed' : ''}`}>
            <div className="step-number">2</div>
            <span>Date & Time</span>
          </div>
          <div className="step-line"></div>
          <div className={`step ${step >= 3 ? 'active' : ''}`}>
            <div className="step-number">3</div>
            <span>Workstation</span>
          </div>
        </div>

        {/* Step 1: Select Lab */}
        {step === 1 && (
          <div className="step-content">
            <h2>Select a Lab</h2>
            <div className="labs-grid">
              {labs.map((lab) => (
                <div 
                  key={lab.id} 
                  className="lab-card"
                  onClick={() => handleLabSelect(lab.id)}
                >
                  <div className="lab-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                      <line x1="8" y1="21" x2="16" y2="21"/>
                      <line x1="12" y1="17" x2="12" y2="21"/>
                    </svg>
                  </div>
                  <h3>{lab.name}</h3>
                  <p>{lab.capacity} Workstations</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Date & Time */}
        {step === 2 && (
          <div className="step-content">
            <h2>Select Date & Time</h2>
            <div className="booking-form-card">
              <div className="selected-lab-info">
                <span>Selected Lab:</span>
                <strong>{selectedLab?.name}</strong>
              </div>
              <form onSubmit={handleDateTimeSubmit}>
                <div className="form-group">
                  <label>Date</label>
                  <input 
                    type="date" 
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>Start Time</label>
                    <select 
                      required
                      value={formData.startTime}
                      onChange={(e) => setFormData({...formData, startTime: e.target.value})}
                    >
                      <option value="">Select</option>
                      {timeSlots.map(time => (
                        <option key={time} value={time}>{time}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>End Time</label>
                    <select 
                      required
                      value={formData.endTime}
                      onChange={(e) => setFormData({...formData, endTime: e.target.value})}
                    >
                      <option value="">Select</option>
                      {timeSlots.map(time => (
                        <option key={time} value={time}>{time}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="form-actions">
                  <button type="button" className="btn-back" onClick={() => setStep(1)}>Back</button>
                  <button type="submit" className="btn-next">Continue</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Step 3: Select Workstation */}
        {step === 3 && (
          <div className="step-content">
            <h2>Select a Workstation</h2>
            <div className="booking-summary">
              <div className="summary-item">
                <span>Lab:</span>
                <strong>{selectedLab?.name}</strong>
              </div>
              <div className="summary-item">
                <span>Date:</span>
                <strong>{formData.date}</strong>
              </div>
              <div className="summary-item">
                <span>Time:</span>
                <strong>{formData.startTime} - {formData.endTime}</strong>
              </div>
            </div>

            <div className="workstation-grid">
              {workstations.map((pc) => (
                <div 
                  key={pc.id}
                  className={`workstation ${pc.status} ${formData.workstationId === pc.id ? 'selected' : ''}`}
                  onClick={() => pc.status === 'available' && handleWorkstationSelect(pc.id)}
                >
                  <div className="pc-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                      <line x1="8" y1="21" x2="16" y2="21"/>
                      <line x1="12" y1="17" x2="12" y2="21"/>
                    </svg>
                  </div>
                  <span>{pc.name}</span>
                  <small>{pc.status}</small>
                </div>
              ))}
            </div>

            <div className="legend">
              <div className="legend-item">
                <span className="dot available"></span>
                <span>Available</span>
              </div>
              <div className="legend-item">
                <span className="dot occupied"></span>
                <span>Occupied</span>
              </div>
              <div className="legend-item">
                <span className="dot selected"></span>
                <span>Selected</span>
              </div>
            </div>

            <div className="form-actions">
              <button className="btn-back" onClick={() => setStep(2)}>Back</button>
              <button 
                className="btn-book"
                disabled={!formData.workstationId || loading}
                onClick={handleBooking}
              >
                {loading ? (
                  <span className="spinner"></span>
                ) : (
                  'Confirm Booking'
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default BookWorkstation;
